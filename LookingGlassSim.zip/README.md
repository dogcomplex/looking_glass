# LookingGlassSim (scaffold)

A small, runnable scaffold for the "Looking Glass" ternary analog optical loop simulator.

## Quick start
```
python examples/run_smoke.py
```

This runs a tiny end-to-end chain with synthetic parameter packs and prints a summary dict.
