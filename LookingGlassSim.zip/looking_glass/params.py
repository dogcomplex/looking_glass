# Placeholder for shared dataclasses if needed later
