# Looking Glass package init
